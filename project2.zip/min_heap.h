//**************************************************************************
//Frank MacDonald
//Project 2 of 3610
//March 7th 2018
//The file for the structure of the min heap.
//**************************************************************************
#include <vector>
#include <algorithm>
using namespace std;

template <typename T>
struct HeapNode {
  HeapNode(const T data, const int key) : data(data), key(key) {}
  bool operator<(const HeapNode<T>& rhs) {return this->key < rhs.key;}
  bool operator<=(const HeapNode<T>& rhs) {return this->key <= rhs.key;}

  T data;
  int key;
};

template <typename T>
class MinHeap {
public:
  MinHeap() {}
  ~MinHeap() {}

  void insert(const T data, const int key);
  T extract_min();
  T peek() const {return heap[0].data;};
  int size() const {return heap.size();};
  void bubble_down(int thing);
  void bubble_up(int thing);       

private:
  vector<HeapNode<T> > heap;
};
//*********************************************************************************
template <typename T>
void MinHeap<T>::insert(const T data, const int key) {  // need to implement this function
	int i = heap.size()-1;	
	HeapNode<T> temp(data,key);
	heap.push_back(temp);
	bubble_up(i);		

}
//*********************************************************************************
template <typename T>
T MinHeap<T>::extract_min() {                          // need to implement this function
	
	int i = heap.size()-1;
	HeapNode<T> temp(heap[0].data,heap[0].key);
	swap(heap[0],heap[i]);
	heap.pop_back();
	bubble_down(0);
	return temp.data;

}
//*********************************************************************************
template <typename T>
void MinHeap<T>::bubble_down(int thing)
{
int left = 2 * thing + 1;
int right = 2 * thing + 2;
int smallest_value = thing;
	if(left < heap.size() && heap[left].key < heap[thing].key)
	{
		smallest_value = left;
	}
	if(right < heap.size() && heap[right].key < heap[smallest_value].key)
	{
		smallest_value = right;
	}
	if(smallest_value != thing)
	{
		swap(heap[thing], heap[smallest_value]);
		bubble_down(smallest_value);
	}
}
//*********************************************************************************
template <typename T>
void MinHeap<T>::bubble_up(int thing)
{
int left = 2 * thing + 1;
int right = 2 * thing + 2;
int smallest_value = (thing - 1) / 2;


	if(smallest_value = 0)
	{
		return;
	}
	if(heap[smallest_value].key > heap[thing].key)
	{
		HeapNode<T> temp(heap[0].data,heap[0].key);
		temp = heap[smallest_value];
		heap[smallest_value] = heap[thing];
		heap[thing] = temp;
		bubble_up(smallest_value);
	}

}










