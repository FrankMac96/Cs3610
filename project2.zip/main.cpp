//**************************************************************************
//Frank MacDonald
//Project 2 of 3610
//March 7th 2018
//The main file for the huffman/min-heap
//**************************************************************************
#include <iostream>
#include <fstream>
#include "huffman_tree.h"
using namespace std;
int main(int argc, char** argv) {
  // Create a HuffmanTree object and read the input messages into the
  // HuffmanTree construct function. Next, print the encoded message.
  // Finally, destruct the huffman tree and move on to the next test case.

  //The time complexity with the min-heap is nLog(n)
  //The time complexity without the min-heap would only be Log(n)
	HuffmanTree huff;
	string data;
	int tracker;
	cout << "Please enter the required amount of phrases.(This is a number)\n";
	cin >> tracker;

	int i = 0;
	while(i < tracker)
	{	

		cout <<"Enter a string\n";
		while(cin.peek() == '\n' || cin.peek() == '\r')
		{
			cin.ignore();
	
		}
		getline(cin,data);
		huff.construct(data);
		huff.print();
		huff.destruct();
		
		i++;
	}


	return 0;
}

