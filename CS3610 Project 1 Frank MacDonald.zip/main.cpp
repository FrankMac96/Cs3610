#include <iostream>
#include "LinkedList.h"
using namespace std;
char menu();
int main(int argc, char** argv) {
  LinkedList<int> list;
  char choice;
  int data;


    choice = menu();
	while(choice != 'q' || choice != 'Q'){
	    switch(choice){
	    case 'A':
        case 'a':
            cout << "Please enter a data value\n";
            cin >> data;
            cout << "Adding to the list\n";
            list.push_front(data);
		break;
	    case 'D':
		case 'd':
            cout << "Deleting the first node\n";
            list.pop_front();
		break;
	    case 'R':
        case 'r':
            cout << "The list will be sorted in reverse order.\n";
            list.reverse();
		break;
	    case 'P':
        case 'p':
            cout << "Printing the values of each node...\n";
            list.print();
		break;
	    case 'Q':
        case 'q':
            cout<<"Exiting program...\n";
            return 0;
		break;
	    default:
            cout << "Not an option.\n";
            cout << "Please enter another option.\n";
		break;
	    } //bottom of the switch
	    choice = menu();
	}// bottom of the while loop, which is a sentential loop

  return 0;
}
char menu(){
    char choice;
    cout << "Choose from the following options:\n";
    cout << "a i) Add the integer i to the front of the list.(push_front)\n";
    cout << "d) Delete the first element of the list.(pop_front)\n";
    cout << "r) Reverse the list.\n";
    cout << "p) Print the data value of each node in the list.\n";
    cout << "q) Quit the program.\n";
    cin >> choice;

    return choice;
}
